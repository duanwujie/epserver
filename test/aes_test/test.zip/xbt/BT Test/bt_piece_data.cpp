#include "stdafx.h"
#include "bt_piece_data.h"

Cbt_piece_data::Cbt_piece_data()
{
}
