#include "stdafx.h"
#include "bt_peer_data.h"

Cbt_peer_data::Cbt_peer_data()
{
}
