#pragma once

class Cbt_piece_data  
{
public:
	Cbt_piece_data();

	bool m_valid;
	int m_priority;
};
