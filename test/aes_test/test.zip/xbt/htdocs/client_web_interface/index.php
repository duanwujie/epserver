<?php
	$title = 'XBT Client Web Interface';
	include('../top.php');
?>
<h2>Overview</h2>

<p>
XBT Client Web Interface is a frontend for XBT Client Backend.<br>

<hr>
<h2>Screenshots</h2>

<p>
<img src="images/0.png">

<p>
<img src="images/1.png">

<p>
<img src="images/2.png">

<p>
<img src="images/3.png">
<?php
	include('../bottom.php');
?>