<?php
	$title = 'Extended BitTorrent';
	include('top.php');
?>
<p>
XBT is high-performance low-overhead BitTorrent software.

<p>
<a href="client">XBT Client</a> (XBTC)

<p>
<a href="client_backend">XBT Client Backend</a>

<p>
<a href="client_command_line_interface">XBT Client Command Line Interface</a>

<p>
<a href="client_web_interface">XBT Client Web Interface</a>

<p>
<a href="tracker">XBT Tracker</a> (XBTT)

<p>
<a href="udp_tracker_protocol.html">UDP Tracker protocol</a>
<?php
	include('bottom.php');
