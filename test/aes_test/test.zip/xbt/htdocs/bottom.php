<hr>
<div>
	<a href="http://sourceforge.net/projects/xbtt/"><img src="http://sourceforge.net/sflogo.php?group_id=94951;type=1" alt="XBT project at SF"></a>
	<a href="http://sourceforge.net/donate/index.php?group_id=94951"><img src="http://images.sourceforge.net/images/project-support.jpg" alt="Donate to this project"></a>
	<a href="http://w3.org/"><img src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS!"></a>
	<a href="http://w3.org/"><img src="http://w3.org/Icons/valid-html401" alt="Valid HTML 4.01!"></a>
</div>