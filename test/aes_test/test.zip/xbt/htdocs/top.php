<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<link rel=stylesheet href="/xbt.css">
<title><?=$title?> by Olaf van der Spek</title>
<table width="100%">
	<tr>
		<td align=left valign=bottom><h1><?=$title?></h1>
		<td align=right valign=bottom>
				<a href="/">Home</a> |
				<a href="/client/">Client</a> |
				<a href="/client_backend/">Client Backend</a> |
				<a href="/tracker/">Tracker</a>
</table>
<hr>
