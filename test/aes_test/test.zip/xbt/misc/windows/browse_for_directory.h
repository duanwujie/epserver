#pragma once

int browse_for_directory(HWND, const std::string& title, std::string& directory);
