#pragma once
#pragma warning(disable: 4786)

#include <cstring>
#include <ctime>
#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <socket.h>
#include <vector>
#include <xbt/virtual_binary.h>

#ifndef WIN32
#include <stdint.h>
#endif
